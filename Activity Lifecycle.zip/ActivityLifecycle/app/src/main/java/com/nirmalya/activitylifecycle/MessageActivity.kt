package com.nirmalya.activitylifecycle

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class MessageActivity : AppCompatActivity() {
    var avengerName:String? = "nirmalya"
    lateinit var txtFavAvenger: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_message)

        txtFavAvenger=findViewById(R.id.txtFavAvenger)

        if(intent !=null){
            avengerName=intent.getStringExtra("NAMEE")

        }
        title="YOUR FAVOURITE AVENGER"
        txtFavAvenger.text= avengerName
    }
}