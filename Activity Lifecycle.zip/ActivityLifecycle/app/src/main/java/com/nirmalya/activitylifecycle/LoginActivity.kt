package com.nirmalya.activitylifecycle

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast

class LoginActivity : AppCompatActivity(){



    lateinit var etMoblieNumber: EditText
     lateinit var etPasswardd: EditText
    lateinit var btnLogin: Button
    lateinit var txtRegister : TextView
   lateinit var txtForgot : TextView
    val validMoblileNumber = "9674240883"
    val validPassward = arrayOf("tony","steve","thor","nirmalya")


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        title="LOG IN"

        etMoblieNumber = findViewById(R.id.etMobileNumber)
        etPasswardd = findViewById(R.id.etPasswardd)
        btnLogin = findViewById(R.id.btnLogin)
        txtRegister = findViewById(R.id.txtRegister)
        txtForgot = findViewById(R.id.txtForgot)



        btnLogin.setOnClickListener {
            val mobileNumber = etMoblieNumber.text.toString()
            val password = etPasswardd.text.toString()
            var nameOfAvenger="AVENGER"
            val intent = Intent(this@LoginActivity,AvengersActivity::class.java)

            if(mobileNumber==validMoblileNumber){
                if(password == validPassward[0]){
                    nameOfAvenger="IRON MAN"
                    intent.putExtra("NAME",nameOfAvenger)
                    startActivity(intent)

                }else if(password == validPassward[1]){
                    nameOfAvenger="CAPTAIN AMERICA"
                    intent.putExtra("NAME",nameOfAvenger)
                    startActivity(intent)

                }else if(password == validPassward[2]){
                    nameOfAvenger="THOR"
                    intent.putExtra("NAME",nameOfAvenger)
                    startActivity(intent)

                }else if(password == validPassward[3]){
                    nameOfAvenger="AVENGERS"
                    intent.putExtra("NAME",nameOfAvenger)
                    startActivity(intent)
                }
           }
            else{
               Toast.makeText(this@LoginActivity,"INCORRECT CREDENTIALS",Toast.LENGTH_LONG).show()
           }
        }
    }
    override fun onPause(){
        super.onPause()
        finish()
    }
}
