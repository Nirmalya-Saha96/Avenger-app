package com.nirmalya.activitylifecycle

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.nirmalya.activitylifecycle.R.layout.*

class AvengersActivity : AppCompatActivity() {

    var titleName:String? = "AVENGERS"
    lateinit var txtNameMe: TextView
    lateinit var txtRelationMe: TextView
    lateinit var txtNameCaptain: TextView
    lateinit var txtRealtionCaptain: TextView
    lateinit var txtRealtionCaptainPower: TextView
    lateinit var txtNameThor: TextView
    lateinit var txtRelationThor: TextView
    lateinit var txtRealtionThorPower: TextView
    lateinit var txtNameTony: TextView
    lateinit var txtRelationTony: TextView
    lateinit var txtRealtionTonyPower: TextView
    lateinit var txtNameHulk: TextView
    lateinit var txtRelationHulk: TextView
    lateinit var txtRealtionHulkPower: TextView
    lateinit var txtNamePanther: TextView
    lateinit var txtRelationPanther: TextView
    lateinit var txtRealtionPantherPower: TextView
    lateinit var txtNameWidow: TextView
    lateinit var txtRelationWidow: TextView
    lateinit var txtRealtionWidowPower: TextView
    lateinit var etEnterText: EditText
    lateinit var btnSent:Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(scrollvieww_example)

        if(intent != null){
            titleName =intent.getStringExtra("NAME")
        }

        title= titleName

        txtNameMe=findViewById(R.id.txtNameMe)
        txtRelationMe=findViewById(R.id.txtRelationMe)
        txtNameCaptain=findViewById(R.id.txtNameCaptain)
        txtRealtionCaptain=findViewById(R.id.txtRealtionCaptain)
        txtRealtionCaptainPower=findViewById(R.id.txtRealtionCaptainPower)
        txtNameThor=findViewById(R.id.txtNameThor)
        txtRelationThor=findViewById(R.id.txtRelationThor)
        txtRealtionThorPower=findViewById(R.id.txtRealtionThorPower)
        txtNameTony=findViewById(R.id.txtNameTony)
        txtRelationTony=findViewById(R.id.txtRelationTony)
        txtRealtionTonyPower=findViewById(R.id. txtRealtionTonyPower)
        txtNameHulk=findViewById(R.id.txtNameHulk)
        txtRelationHulk=findViewById(R.id.txtRelationHulk)
        txtRealtionHulkPower=findViewById(R.id.txtRealtionHulkPower)
        txtNamePanther=findViewById(R.id.txtNamePanther)
        txtRelationPanther=findViewById(R.id.txtRelationPanther)
        txtRealtionPantherPower=findViewById(R.id.txtRealtionPantherPower)
        txtNameWidow=findViewById(R.id.txtNameWidow)
        txtRelationWidow=findViewById(R.id.txtRelationWidow)
        txtRealtionWidowPower=findViewById(R.id.txtRealtionWidowPower)
        etEnterText=findViewById(R.id.etEnterText)
        btnSent=findViewById(R.id.btnSent)


        btnSent.setOnClickListener{
            val enterText=etEnterText.text.toString()
            val intent= Intent(this@AvengersActivity,MessageActivity::class.java)
            intent.putExtra("NAMEE",enterText)
            Toast.makeText(this@AvengersActivity,"SUBMIT SUCCESSFULLY",Toast.LENGTH_LONG).show()
            startActivity(intent)

        }



    }

}